package organization

import "blockchain/smcsdk/sdk/std"

func (o *Organization) _organization(orgID string) std.Organization {
	return *o.sdk.Helper().StateHelper().GetEx("/organization/"+orgID, new(std.Organization)).(*std.Organization)
}

func (o *Organization) _setOrganization(org std.Organization) {
	o.sdk.Helper().StateHelper().Set("/organization/"+org.OrgID, &org)
}

func (o *Organization) _chkOrganization(orgID string) bool {
	return o.sdk.Helper().StateHelper().Check("/organization/" + orgID)
}
