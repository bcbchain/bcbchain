package tokenissue

import "blockchain/smcsdk/sdk/forx"

func (ti *TokenIssue) isCallByIBC() bool {
	origins := ti.sdk.Message().Origins()
	if len(origins) < 1 {
		return false
	}

	lastContract := ti.sdk.Helper().ContractHelper().ContractOfAddress(origins[len(origins)-1])
	if lastContract.Name() == "ibc" && lastContract.OrgID() == ti.sdk.Helper().GenesisHelper().OrgID() {
		return true
	}

	return false
}

func (ti *TokenIssue) getNotifyChainIDs() []string {
	toChainIDs := ti._supportSideChains(ti.sdk.Message().Contract().Token())

	newToChainIDs := []string{}
	forx.Range(toChainIDs, func(index int, toChainID string) bool {
		chainInfo := ti._chainInfo(toChainID)
		if chainInfo.Status != "" &&
			chainInfo.Status != "disabled" &&
			!inSlice(newToChainIDs, toChainID) {

			newToChainIDs = append(newToChainIDs, toChainID)
		}

		return forx.Continue
	})

	return newToChainIDs
}

func inSlice(slice []string, item string) bool {
	exist := false
	forx.Range(slice, func(index int, s string) bool {
		if item == s {
			exist = true
			return forx.Break
		}
		return forx.Continue
	})
	return exist
}
