package tokenissue

import (
	"blockchain/smcsdk/sdk/bn"
	"blockchain/smcsdk/sdk/forx"
	"blockchain/smcsdk/sdk/std"
	"blockchain/smcsdk/sdk/types"
)

func (ti *TokenIssue) _chkSideChainID(chainID string) bool {
	return ti.sdk.Helper().StateHelper().Check(keyOfChainInfo(chainID))
}

func (ti *TokenIssue) _setAccountBalance(account, token types.Address, balance bn.Number) {
	key := std.KeyOfAccountToken(account, token)
	info := std.AccountInfo{
		Address: ti.sdk.Message().Contract().Token(),
		Balance: balance,
	}
	ti.sdk.Helper().StateHelper().Set(key, &info)
}

func (ti *TokenIssue) _accountBalance(account, token types.Address) bn.Number {
	key := std.KeyOfAccountToken(account, token)
	return ti.sdk.Helper().StateHelper().GetEx(key, new(std.AccountInfo)).(*std.AccountInfo).Balance
}

func (ti *TokenIssue) _peerChainBalance(tokenAddr types.Address, chainID string) bn.Number {
	key := keyOfPeerChainBal(tokenAddr, chainID)
	bn0 := bn.N(0)
	return *ti.sdk.Helper().StateHelper().GetEx(key, &bn0).(*bn.Number)
}

func (ti *TokenIssue) _setPeerChainBalance(tokenAddr types.Address, chainID string, balance bn.Number) {
	key := keyOfPeerChainBal(tokenAddr, chainID)
	ti.sdk.Helper().StateHelper().Set(key, &balance)
}

func (ti *TokenIssue) _chainInfo(chainID string) *ChainInfo {
	return ti.sdk.Helper().StateHelper().GetEx(keyOfChainInfo(chainID), new(ChainInfo)).(*ChainInfo)
}

func (ti *TokenIssue) _supportSideChains(tokenAddr types.Address) []string {
	return *ti.sdk.Helper().StateHelper().GetEx(keyOfSupportSCList(tokenAddr), new([]string)).(*[]string)
}

func (ti *TokenIssue) _setSupportSideChains(tokenAddr types.Address, sideChainNames []string) {
	ti.sdk.Helper().StateHelper().Set(keyOfSupportSCList(tokenAddr), &sideChainNames)
}

// _contract get contract information with orgID and name
func (ti *TokenIssue) _contract(orgID, name string) *std.Contract {
	contractVersions := ti._contractVersions(orgID, name)

	var contract *std.Contract
	forx.RangeReverse(contractVersions.ContractAddrList, func(index int, contractAddr types.Address) bool {
		if ti.sdk.Block().Height() >= contractVersions.EffectHeights[index] {
			key := std.KeyOfContract(contractAddr)
			tempCon := ti.sdk.Helper().StateHelper().GetEx(key, new(std.Contract)).(*std.Contract)
			if tempCon.LoseHeight != 0 && tempCon.LoseHeight < ti.sdk.Block().Height() {
				return forx.Continue
			}

			contract = tempCon
		}

		return true
	})

	return contract
}

// _contractVersions get contract version list with orgID and name
func (ti *TokenIssue) _contractVersions(orgID, name string) *std.ContractVersionList {
	key := std.KeyOfContractsWithName(orgID, name)
	defaultValue := std.ContractVersionList{
		Name:             name,
		ContractAddrList: make([]types.Address, 0),
		EffectHeights:    make([]int64, 0),
	}
	contractVersions := ti.sdk.Helper().StateHelper().GetEx(key, &defaultValue)

	return contractVersions.(*std.ContractVersionList)
}
