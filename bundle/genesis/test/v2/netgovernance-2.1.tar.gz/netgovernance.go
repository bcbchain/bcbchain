package netgovernance

import (
	"blockchain/smcsdk/sdk"
	"blockchain/smcsdk/sdk/bn"
	"blockchain/smcsdk/sdk/forx"
	"blockchain/smcsdk/sdk/jsoniter"
	"blockchain/smcsdk/sdk/std"
	"blockchain/smcsdk/sdk/types"
	"encoding/hex"
	"fmt"
	"regexp"
)

//NetGovernance This is struct of contract
//@:contract:netgovernance
//@:version:2.1
//@:organization:orgJgaGConUyK81zibntUBjQ33PKctpk1K1G
//@:author:5e8339cb1a5cce65602fd4f57e115905348f7e83bcbe38dd77694dbe1f8903c9
type NetGovernance struct {
	sdk       sdk.ISmartContract
	chainInfo *ChainInfo
}

//InitChain Constructor of this NetGovernance
//@:constructor
func (ng *NetGovernance) InitChain() {
	sdk.RequireMainChain()
}

//UpdateChain Constructor of this NetGovernance
//@:constructor
func (ng *NetGovernance) UpdateChain() {
	sdk.RequireMainChain()
}

//@:public:method:gas[50000]
func (ng *NetGovernance) RegisterSideChain(chainName, orgName string, ownerAddr types.Address) {
	// check sender
	sdk.RequireOwner()

	// check chainName
	sideChainID := ng.checkChainName(chainName, false)

	// check organization
	ng.checkOrganization(orgName)

	// check ownerAddr
	ng.checkOwnerAddr(ownerAddr)

	// save chainInfo
	chainInfo := ChainInfo{
		SideChainName: chainName,
		ChainID:       sideChainID,
		OrgName:       orgName,
		Owner:         ownerAddr,
		Status:        Init,
	}
	ng._setChainInfo(chainInfo)

	//save sideChainID
	sideChainIDList := ng._sideChainIDs()
	sideChainIDList = append(sideChainIDList, sideChainID)
	ng._setSideChainIDs(sideChainIDList)

	// send receipt
	ng.emitRegisterSideChainReceipt(sideChainID, orgName, ownerAddr)
}

//@:public:method:gas[5000000]
func (ng *NetGovernance) GenesisSideChain(
	chainName string,
	nodeName string,
	nodePubKey types.PubKey,
	rewardAddr types.Address,
	openURL string,
	gasPriceRatio string) {

	mainOpenURLs := ng._openURLs(ng.sdk.Block().ChainID())
	sdk.Require(len(mainOpenURLs) != 0,
		types.ErrInvalidParameter, "main chain must set openURLs")

	// check chainName
	sideChainID, chainInfo := ng.checkSideChainInfo(chainName, Init)

	// check nodeName
	ng.checkNodeName(nodeName)

	// check nodePubKey
	nodeAddr := ng.checkNodePubKey(nodePubKey, sideChainID)

	// check rewardAddr
	sdk.RequireAddressEx(sideChainID, rewardAddr)

	// check openurl
	openURLs := []string{openURL}
	ng.checkOpenUrls(openURLs)

	// check gasPriceRatio
	gasPriceRatio = ng.checkGasPriceRatio(gasPriceRatio)

	// save urls
	ng._setOpenURLs(sideChainID, openURLs)

	chainInfo.NodeNames = []string{nodeName}
	chainInfo.Status = Ready
	chainInfo.Height = ng.sdk.Block().Height()
	chainInfo.GasPriceRatio = gasPriceRatio
	ng._setChainInfo(chainInfo)

	// generate validator
	validator := Validator{
		PubKey:     nodePubKey,
		Power:      10,
		RewardAddr: rewardAddr,
		Name:       nodeName,
		NodeAddr:   nodeAddr,
	}

	//save Validator
	nodes := make(map[string]Validator)
	nodes[nodeAddr] = validator
	ng._setChainValidator(sideChainID, nodes)

	// send receipt
	genesisInfo, contractsData := ng.makeGenesisInfo(chainInfo, validator)
	ng.emitGenesisSideChainReceipt(
		sideChainID,
		openURLs,
		genesisInfo,
		contractsData)
}

//@:public:method:gas[50000]
func (ng *NetGovernance) SetOpenURLs(chainName string, openURLs []string) {
	//check chainInfo
	var chainID string
	if chainName != ng.sdk.Block().ChainID() {
		chainID, _ = ng.checkSideChainInfo(chainName, Ready)
	} else {
		chainID = ng.checkMainChainInfo()
	}

	//check openURLs
	ng.checkOpenUrls(openURLs)

	//save openURLs
	ng._setOpenURLs(chainID, openURLs)

	// broadcast if chainID is mainChain
	if chainID == ng.sdk.Helper().BlockChainHelper().GetMainChainID() {
		ng.sdk.Helper().IBCHelper().Run(func() {
			ng.emitSetOpenURLReceipt(chainID, openURLs)
		}).Broadcast()
	} else {
		//send receipt
		ng.emitSetOpenURLReceipt(chainID, openURLs)
	}
}

//@:public:method:gas[50000]
func (ng *NetGovernance) SetStatus(chainName string, status string) {
	sdk.RequireOwner()

	// check chain name
	chainID := ng.checkChainName(chainName, true)

	// check status
	chainInfo := ng.checkStatus(chainID, status)

	//save chain status
	chainInfo.Status = status
	ng._setChainInfo(chainInfo)

	//send receipt
	ng.emitSetStatusReceipt(chainID, status)
}

//@:public:method:gas[50000]
func (ng *NetGovernance) SetGasPriceRatio(chainName string, gasPriceRatio string) {
	//check sideChainInfo
	chainID, chainInfo := ng.checkSideChainInfo(chainName, Ready)

	//check gasPriceRatio
	ng.checkGasPriceRatio(gasPriceRatio)

	// update chainInfo
	chainInfo.GasPriceRatio = gasPriceRatio
	ng._setChainInfo(chainInfo)

	toChainIDs := make([]string, 0)
	toChainIDs = append(toChainIDs, chainID)
	ng.sdk.Helper().IBCHelper().Run(func() {
		ng.emitSetGasPriceRatioReceipt(chainInfo.SideChainName, chainID, gasPriceRatio)
	}).Notify(toChainIDs)

}

func (ng *NetGovernance) makeGenesisInfo(
	chainInfo ChainInfo,
	validator Validator) (string, []ContractData) {

	genesisTokenAddr := ng.sdk.Helper().GenesisHelper().Token().Address()
	baseToken := ng.sdk.Helper().TokenHelper().TokenOfAddress(genesisTokenAddr)
	contracts, contractsData := ng.getContractsForGenesis(chainInfo)
	mainChainValidators := ng.getMainChainValidators()
	chainVersion := ng._chainVersion()

	var mainChainInfo MainChainInfo
	mainChainUrls := ng._openURLs(ng.sdk.Block().ChainID())
	mainChainInfo.OpenUrls = mainChainUrls
	mainChainInfo.Validators = mainChainValidators

	bcHelper := ng.sdk.Helper().BlockChainHelper()
	genesis := GenesisInfo{
		ChainID:      chainInfo.ChainID,
		ChainVersion: fmt.Sprintf("%d", chainVersion),
		GenesisTime:  ng.sdk.Helper().BlockChainHelper().FormatTime(ng.sdk.Block().Time(), "2006-01-02T15:04:05.999999999Z07:00"),
		AppHash:      "",
		AppState: AppState{
			Organization:  "genesis",
			GasPriceRatio: chainInfo.GasPriceRatio,
			Token: std.Token{
				Address:          bcHelper.RecalcAddress(genesisTokenAddr, chainInfo.ChainID),
				Owner:            bcHelper.RecalcAddress(baseToken.Owner().Address(), chainInfo.ChainID),
				Name:             baseToken.Name(),
				Symbol:           baseToken.Symbol(),
				TotalSupply:      bn.N(0),
				AddSupplyEnabled: baseToken.AddSupplyEnabled(),
				BurnEnabled:      baseToken.BurnEnabled(),
				GasPrice:         baseToken.GasPrice(),
			},
			RewardStrategy: []Reward{
				{
					Name:          "validators",
					RewardPercent: "100.00",
					Address:       "",
				},
			},
			Contracts: contracts,
			OrgBind: OrgBind{
				OrgName: chainInfo.OrgName,
				Owner:   bcHelper.RecalcAddress(chainInfo.Owner, chainInfo.ChainID),
			},
			MainChain: mainChainInfo,
		},
		Validators: []Validator{validator},
	}

	info, err := jsoniter.Marshal(genesis)
	sdk.RequireNotError(err, types.ErrInvalidParameter)

	return string(info), contractsData
}

func (ng *NetGovernance) getContractsForGenesis(chainInfo ChainInfo) (contracts []Contract, contractData []ContractData) {

	genesisContracts := []string{"token-basic", "token-issue", "governance",
		"organization", "smartcontract", "ibc"}

	forx.Range(genesisContracts, func(i int, genesisContract string) bool {
		c := ng.sdk.Helper().ContractHelper().ContractOfName(genesisContract)

		contractOwner := ""
		if genesisContract == "governance" {
			contractOwner = ng.sdk.Helper().BlockChainHelper().RecalcAddress(chainInfo.Owner, chainInfo.ChainID)
		}

		codeDevSig, codeOrgSig := ng.getConCodeSig(c.Address())
		code := c.Name() + "-" + c.Version() + ".tar.gz"
		con := Contract{
			Name:       c.Name(),
			Version:    c.Version(),
			Code:       code,
			CodeHash:   hex.EncodeToString(c.CodeHash()),
			Owner:      contractOwner,
			CodeDevSig: codeDevSig,
			CodeOrgSig: codeOrgSig,
		}
		contracts = append(contracts, con)

		conData := ContractData{
			Name:     c.Name(),
			Version:  c.Version(),
			CodeByte: ng._contractCode(c.Address()),
		}
		contractData = append(contractData, conData)

		return forx.Continue
	})

	return contracts, contractData
}

// 公钥对应的节点不能是主链的节点
func (ng *NetGovernance) checkNodePubKey(nodePubKey types.PubKey, sideChainID string) types.Address {
	mainChainAddr := ng.sdk.Helper().BlockChainHelper().CalcAccountFromPubKey(nodePubKey)

	sdk.Require(!ng._chkBCBValidator(mainChainAddr),
		types.ErrInvalidParameter, "Can not use mainChain validator")

	sideChainNodeAddr := ng.sdk.Helper().BlockChainHelper().RecalcAddress(mainChainAddr, sideChainID)

	return sideChainNodeAddr
}

func (ng *NetGovernance) checkOrganization(orgName string) {

	sdk.Require(len(orgName) > 0,
		types.ErrInvalidParameter, "Invalid orgName")

	genesisOrgID := ng.sdk.Helper().GenesisHelper().OrgID()
	orgID := ng.sdk.Helper().BlockChainHelper().CalcOrgID(orgName)
	sdk.Require(orgID != genesisOrgID,
		types.ErrInvalidParameter, "SideChain organization could not be genesis organization")

	sdk.Require(ng._chkOrganization(orgID),
		types.ErrInvalidParameter, "There is no organization with name "+orgName)
}

func (ng *NetGovernance) getConCodeSig(conAddr types.Address) (codeDevSig, codeOrgSig Signature) {

	type contractMeta struct {
		Name         string        `json:"name"`
		ContractAddr types.Address `json:"contractAddr"`
		OrgID        string        `json:"orgID"`
		Version      string        `json:"version"`
		EffectHeight int64         `json:"effectHeight"`
		LoseHeight   int64         `json:"loseHeight"`
		CodeData     []byte        `json:"codeData"`
		CodeHash     []byte        `json:"codeHash"`
		CodeDevSig   []byte        `json:"codeDevSig"`
		CodeOrgSig   []byte        `json:"codeOrgSig"`
	}

	key := std.KeyOfContractCode(conAddr)
	conMeta := ng.sdk.Helper().StateHelper().Get(key, new(contractMeta)).(*contractMeta)

	var codeDevSigStr, codeOrgSigStr string
	err := jsoniter.Unmarshal(conMeta.CodeDevSig, &codeDevSigStr)
	sdk.RequireNotError(err, types.ErrInvalidParameter)

	err = jsoniter.Unmarshal(conMeta.CodeOrgSig, &codeOrgSigStr)
	sdk.RequireNotError(err, types.ErrInvalidParameter)

	codeDevSigByte := []byte(codeDevSigStr)
	codeOrgSigByte := []byte(codeOrgSigStr)

	err = jsoniter.Unmarshal(codeDevSigByte, &codeDevSig)
	sdk.RequireNotError(err, types.ErrInvalidParameter)

	err = jsoniter.Unmarshal(codeOrgSigByte, &codeOrgSig)
	sdk.RequireNotError(err, types.ErrInvalidParameter)

	return codeDevSig, codeOrgSig
}

func (ng *NetGovernance) getMainChainValidators() map[string]Validator {

	mainChainValidatorAddrList := ng._bcbValidator()
	mainChainValidators := make(map[string]Validator)
	forx.Range(mainChainValidatorAddrList, func(i int, addr string) {
		valInfo := *ng.sdk.Helper().StateHelper().GetEx("/validator/"+addr,
			&Validator{}).(*Validator)
		mainChainValidators[addr] = valInfo
	})

	return mainChainValidators
}

func (ng *NetGovernance) checkChainName(chainName string, occupiedWanted bool) (chainID string) {
	sdk.Require(chainName != "",
		types.ErrInvalidParameter, "ChainName should not be nil")

	sdk.Require(chainName != ng.sdk.Block().ChainID(),
		types.ErrInvalidParameter, "ChainName should not be mainChain")

	chainID = ng.sdk.Helper().BlockChainHelper().CalcSideChainID(chainName)

	var errInfo string
	if occupiedWanted == false {
		errInfo = "ChainName has been occupied "
	} else {
		errInfo = "ChainName does not exits "
	}
	sdk.Require(ng._chkChainInfo(chainID) == occupiedWanted,
		types.ErrInvalidParameter, errInfo)

	return
}

func (ng *NetGovernance) checkOwnerAddr(ownerAddr types.Address) {
	//检查地址格式
	sdk.RequireAddress(ownerAddr)

	//侧链Owner地址不能为主链委员会地址
	genesisOwnerAddr := ng.sdk.Message().Contract().Owner().Address()
	sdk.Require(ownerAddr != genesisOwnerAddr,
		types.ErrInvalidParameter, "Invalid owner Address")
}

func (ng *NetGovernance) checkOpenUrls(openURLs []string) {

	sdk.Require(len(openURLs) > 0,
		types.ErrInvalidParameter, "OpenUrls should not be empty")

	urlExpr := `^(https|http)://`
	forx.Range(openURLs, func(i int, openURL string) bool {
		match, _ := regexp.MatchString(urlExpr, openURL)
		sdk.Require(match,
			types.ErrInvalidParameter, fmt.Sprintf("Invalid openURL: %v ", openURL))

		return forx.Continue
	})
}

func (ng *NetGovernance) checkSideChainInfo(chainName, statusWanted string) (chainID string, chainInfo ChainInfo) {
	// check chainName
	chainID = ng.checkChainName(chainName, true)

	// check sender
	sdk.Require(ng.sdk.Message().Sender().Address() == ng._chainInfo(chainID).Owner,
		types.ErrNoAuthorization, "Only SideChain Owner can do this ")

	// check chain status
	chainInfo = ng._chainInfo(chainID)
	sdk.Require(chainInfo.Status == statusWanted,
		types.ErrInvalidParameter, "The status of sideChain is error ")

	return
}

func (ng *NetGovernance) checkMainChainInfo() string {
	//check Sender
	sdk.RequireOwner()

	return ng.sdk.Helper().BlockChainHelper().GetMainChainID()
}

func (ng *NetGovernance) checkNodeName(nodeName string) {
	sdk.Require(len(nodeName) > 0 && len(nodeName) <= MaxNameLen,
		types.ErrInvalidParameter, fmt.Sprintf("The length of nodeName should be within (0,%d]", MaxNameLen))
}

func (ng *NetGovernance) checkStatus(chainID, status string) ChainInfo {
	chainInfo := ng._chainInfo(chainID)
	sdk.Require((status == Ready && chainInfo.Status == Clear) ||
		(status == Clear && chainInfo.Status == Ready) ||
		(status == Disabled && chainInfo.Status == Clear),
		types.ErrInvalidParameter, "Status value error!")

	return chainInfo
}

func (ng *NetGovernance) checkGasPriceRatio(gasPriceRatio string) string {
	//检查为空
	if gasPriceRatio == "" {
		return "1.000"
	}

	//检查格式精确到小数点后三位
	urlExpr := `^[0-9]+(.[0-9]{3})?$`
	match, _ := regexp.MatchString(urlExpr, gasPriceRatio)
	sdk.Require(match,
		types.ErrInvalidParameter, fmt.Sprintf("Invalid gasPriceRatio: %v ", gasPriceRatio))

	return gasPriceRatio
}
