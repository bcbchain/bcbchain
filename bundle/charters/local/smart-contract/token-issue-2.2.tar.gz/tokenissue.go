package tokenissue

import (
	"blockchain/smcsdk/sdk"
	"blockchain/smcsdk/sdk/bn"
	"blockchain/smcsdk/sdk/forx"
	"blockchain/smcsdk/sdk/std"
	"blockchain/smcsdk/sdk/types"
	"fmt"
)

//TokenIssue a genesis contract for issuing token and token management
//@:contract:token-issue
//@:version:2.2
//@:organization:orgJgaGConUyK81zibntUBjQ33PKctpk1K1G
//@:author:5e8339cb1a5cce65602fd4f57e115905348f7e83bcbe38dd77694dbe1f8903c9
type TokenIssue struct {
	sdk sdk.ISmartContract
}

const (
	// Define the minimum of token supply for issuing new token.
	// It's one TOKEN, 1,000,000,000 cong
	minTotalsupply = 1000000000
	// token name can be up to 40 characters
	maxNameLen = 40
	// token symbol can be up to 20 characters
	maxSymbolLen = 20
	// maximum gas price
	maxGasPrice = 1000000000
	// maximum number of accounts for batch transfer
	maxPerBatchTransfer = 1000
	// minimum name length for genesis organization issuing new token
	minNameLenForGenesisOrg = 2
	// minimum name length for other organization issuing new token
	minNameLenForOtherOrg = 3
	// minimum symbol length for genesis organization issuing new token
	minSymbolLenForGenesisOrg = 2
	// minimum symbol length for genesis organization issuing new token
	minSymbolLenForOtherOrg = 3
)

//InitChain Constructor of this TokenIssue
//@:constructor
func (ti *TokenIssue) InitChain() {

}

//UpdateChain UpdateChain of this TokenIssue
//@:constructor
func (ti *TokenIssue) UpdateChain() {
	contracts := ti.getAllTokenContract()
	tokenIssue := ti.sdk.Message().Contract()
	stateHelper := ti.sdk.Helper().StateHelper()

	forx.Range(*contracts, func(i int, c std.Contract) bool {
		// update last token contract
		c.LoseHeight = ti.sdk.Block().Height()
		stateHelper.McSet(std.KeyOfContract(c.Address), &c)

		// calc token contract's address
		addr := ti.sdk.Helper().BlockChainHelper().CalcContractAddress(
			c.Name,
			tokenIssue.Version(),
			tokenIssue.OrgID())
		newContract := std.Contract{
			Address:      addr,
			Account:      c.Account,
			Owner:        c.Owner,
			Name:         c.Name,
			Version:      tokenIssue.Version(),
			CodeHash:     tokenIssue.CodeHash(),
			EffectHeight: tokenIssue.EffectHeight(),
			LoseHeight:   0,
			KeyPrefix:    c.KeyPrefix,
			Methods:      tokenIssue.Methods(),
			Interfaces:   tokenIssue.Interfaces(),
			IBCs:         tokenIssue.IBCs(),
			Token:        c.Token,
			OrgID:        c.OrgID,
			ChainVersion: c.ChainVersion,
		}
		stateHelper.McSet(std.KeyOfContract(addr), &newContract)

		// add new contract to contract version information with addresses and effectHeights
		//var cvl std.ContractVersionList
		key := std.KeyOfContractsWithName(c.OrgID, c.Name)
		cvl := stateHelper.McGetEx(key, new(std.ContractVersionList)).(*std.ContractVersionList)
		cvl.ContractAddrList = append(cvl.ContractAddrList, addr)
		cvl.EffectHeights = append(cvl.EffectHeights, newContract.EffectHeight)
		stateHelper.McSet(key, &cvl)

		// add new contract address to account's contract addresses
		key = std.KeyOfAccountContracts(newContract.Owner)
		cons := *stateHelper.McGetEx(key, new([]types.Address)).(*[]types.Address)
		cons = append(cons, addr)
		stateHelper.McSet(key, &cons)
		return true
	})
}

//NewToken register a token
//Notes: Once a token is registered by NewToken() call, it will own a contract exactly same with this contract,
//       but its contract cannot be used to register a new token again.
//       That means only the NewToken() of genesis contract of "token-issue" can be executed.
//       And the genesis contract "token-issue" will never own a token.
//@:public:method:gas[500000]
func (ti *TokenIssue) NewToken(
	name string,
	symbol string,
	totalSupply bn.Number,
	addSupplyEnabled bool,
	burnEnabled bool,
	gasPrice int64) (address types.Address) {

	sdk.RequireMainChain()
	sdk.Require(ti.isValidNameAndSymbol(name, symbol),
		types.ErrInvalidParameter, "Invalid name or symbol")

	address = ti.sdk.Helper().BlockChainHelper().CalcContractAddress(
		"token-templet-"+name,
		ti.sdk.Message().Contract().Version(),
		ti.sdk.Message().Contract().OrgID(),
	)

	ti.newToken(
		address,
		ti.sdk.Message().Sender().Address(),
		name,
		symbol,
		totalSupply,
		addSupplyEnabled,
		burnEnabled,
		gasPrice,
	)

	return
}

//Transfer transfers token to an account
//@:public:method:gas[600]
//@:public:interface:gas[60]
func (ti *TokenIssue) Transfer(to types.Address, value bn.Number) {

	// If it is the genesis contract, cannot execute this function.
	sdk.Require(ti.sdk.Message().Contract().Token() != "",
		types.ErrNoAuthorization, "The contract has not a token")

	if ti.sdk.Helper().BlockChainHelper().IsPeerChainAddress(to) {
		err := ti.sdk.Helper().TokenHelper().CheckActivate(to)
		sdk.RequireNotError(err, types.ErrInvalidParameter)

		// cross chain transfer
		ti.sdk.Helper().IBCHelper().Run(func() {
			ti.lock(to, value)
		}).Register(ti.sdk.Helper().BlockChainHelper().GetChainID(to))
	} else {
		// Do transfer
		ti.sdk.Message().Sender().TransferWithNote(to, value, ti.sdk.Tx().Note())
	}
}

//BatchTransfer transfers token to multi accounts
//@:public:method:gas[6000]
func (ti *TokenIssue) BatchTransfer(toList []types.Address, value bn.Number) {
	sdk.RequireMainChain()

	// If it is the genesis contract, cannot execute this function.
	sdk.Require(ti.sdk.Message().Contract().Token() != "",
		types.ErrNoAuthorization, "The contract has not a token")

	sdk.Require(len(toList) > 0,
		types.ErrInvalidParameter, "Address list cannot be empty")
	sdk.Require(len(toList) <= maxPerBatchTransfer,
		types.ErrInvalidParameter, "Number of accounts is out of range")

	forx.Range(toList, func(i int, to types.Address) bool {
		ti.sdk.Message().Sender().Transfer(to, value)
		return true
	})
}

//AddSupply add token's supply after it's issued
//@:public:method:gas[2400]
func (ti *TokenIssue) AddSupply(value bn.Number) {
	sdk.RequireMainChain()

	// If it is the genesis contract, cannot execute this function.
	sdk.Require(ti.sdk.Message().Contract().Token() != "",
		types.ErrNoAuthorization, "The contract has not a token")

	sdk.Require(value.IsGreaterThanI(0),
		types.ErrInvalidParameter, "Value must greater than zero")

	newTotalSupply := ti.sdk.Helper().TokenHelper().Token().TotalSupply().Add(value)
	ti.sdk.Helper().TokenHelper().Token().SetTotalSupply(newTotalSupply)
}

//Burn burn token's supply after it's issued
//@:public:method:gas[2400]
func (ti *TokenIssue) Burn(value bn.Number) {
	sdk.RequireMainChain()

	// If it is the genesis contract, cannot execute this function.
	sdk.Require(ti.sdk.Message().Contract().Token() != "",
		types.ErrNoAuthorization, "The contract has not a token")

	sdk.Require(value.IsGreaterThanI(0),
		types.ErrInvalidParameter, "Value must greater than zero")

	newTotalSupply := ti.sdk.Helper().TokenHelper().Token().TotalSupply().Sub(value)
	sdk.Require(newTotalSupply.IsGEI(0),
		types.ErrInvalidParameter, "New totalsupply cannot be negative")

	ti.sdk.Helper().TokenHelper().Token().SetTotalSupply(newTotalSupply)
}

//SetOwner set a new owner to token after it's issued
//@:public:method:gas[2400]
func (ti *TokenIssue) SetOwner(newOnwer types.Address) {
	sdk.RequireMainChain()

	toChainIDs := ti.getNotifyChainIDs()
	if len(toChainIDs) > 0 {
		ti.sdk.Helper().IBCHelper().Run(func() {
			ti.sdk.Message().Contract().SetOwner(newOnwer)
		}).Notify(toChainIDs)
	} else {
		ti.sdk.Message().Contract().SetOwner(newOnwer)
	}
}

//SetGasPrice set token's gasprice after it's issued
//@:public:method:gas[2400]
func (ti *TokenIssue) SetGasPrice(value int64) {
	sdk.RequireMainChain()

	// If it is the genesis contract, cannot execute this function.
	sdk.Require(ti.sdk.Message().Contract().Token() != "",
		types.ErrNoAuthorization, "The contract has not a token")

	toChainIDs := ti.getNotifyChainIDs()
	if len(toChainIDs) > 0 {
		ti.sdk.Helper().IBCHelper().Run(func() {
			ti.sdk.Helper().TokenHelper().Token().SetGasPrice(value)
		}).Notify(toChainIDs)
	} else {
		ti.sdk.Helper().TokenHelper().Token().SetGasPrice(value)
	}
}

//@:public:method:gas[2400]
func (ti *TokenIssue) Activate(tokenName, chainName string) {
	sdk.RequireMainChain()

	sideChainID := ti.sdk.Helper().BlockChainHelper().CalcSideChainID(chainName)
	chainInfo := ti._chainInfo(sideChainID)
	sdk.Require(chainInfo.ChainID == sideChainID,
		types.ErrInvalidParameter, "invalid chainName")

	sdk.Require(ti.sdk.Message().Sender().Address() == chainInfo.Owner,
		types.ErrNoAuthorization, "")
	sdk.Require(chainInfo.Status == "ready",
		types.ErrInvalidParameter,
		fmt.Sprintf("expected chain status: ready, obtain: %s", chainInfo.Status))

	token := ti.sdk.Helper().TokenHelper().TokenOfName(tokenName)
	sdk.Require(token != nil,
		types.ErrInvalidParameter, "invalid token Name")
	sdk.Require(token.TotalSupply().IsGreaterThanI(0),
		types.ErrInvalidParameter, "invalid total supply")

	ti.addSupportSideChain(token.Address(), sideChainID)

	ti.sdk.Helper().IBCHelper().Run(func() {
		ti.emitActivate(chainName, token, token.GasPrice())
	}).Broadcast()
}
