package netgovernance

import (
	"blockchain/smcsdk/sdk/std"
	"blockchain/smcsdk/sdk/types"
)

// ChainInfo
func (ng *NetGovernance) _setChainInfo(ci ChainInfo) {
	ng.sdk.Helper().StateHelper().Set(keyOfChainInfo(ci.ChainID), &ci)
}

func (ng *NetGovernance) _chainInfo(chainID string) ChainInfo {
	return *ng.sdk.Helper().StateHelper().Get(keyOfChainInfo(chainID), new(ChainInfo)).(*ChainInfo)
}

func (ng *NetGovernance) _chkChainInfo(chainID string) bool {
	return ng.sdk.Helper().StateHelper().Check(keyOfChainInfo(chainID))
}

// Organization
func (ng *NetGovernance) _chkOrganization(orgID string) bool {
	return ng.sdk.Helper().StateHelper().Check(keyOfOrganization(orgID))
}

// ChainValidatorPubKeys
func (ng *NetGovernance) _setChainValidator(chainID string, cvp map[string]Validator) {
	ng.sdk.Helper().StateHelper().Set("/ibc/"+chainID, &cvp)
}

// Check BCB validator
func (ng *NetGovernance) _chkBCBValidator(nodeAddr types.Address) bool {
	return ng.sdk.Helper().StateHelper().Check(keyOfBCBValidator(nodeAddr))
}

// Get BCB validator
func (ng *NetGovernance) _bcbValidator() []string {
	return *ng.sdk.Helper().StateHelper().GetEx("/validators/all/0", new([]string)).(*[]string)
}

// set open URL
func (ng *NetGovernance) _setOpenURLs(chainID string, urls []string) {
	ng.sdk.Helper().StateHelper().Set(keyOfOpenURLs(chainID), &urls)
}

// Get open URL
func (ng *NetGovernance) _openURLs(chainID string) []string {
	return *ng.sdk.Helper().StateHelper().GetEx(keyOfOpenURLs(chainID), new([]string)).(*[]string)
}

// contract code
func (ng *NetGovernance) _contractCode(contractAddr types.Address) []byte {
	key := keyOfContractCode(contractAddr)
	contractMeta := ng.sdk.Helper().StateHelper().GetEx(key, new(std.ContractMeta)).(*std.ContractMeta)
	return contractMeta.CodeData
}

// validator
func (ng *NetGovernance) _setSideChainIDs(sideChainIDs []string) {
	ng.sdk.Helper().StateHelper().Set(keyOfSideChainIDs(), &sideChainIDs)
}

func (ng *NetGovernance) _sideChainIDs() []string {
	return *ng.sdk.Helper().StateHelper().GetEx(keyOfSideChainIDs(), new([]string)).(*[]string)
}

func (ng *NetGovernance) _chainVersion() int64 {
	type appState struct {
		ChainVersion int64 `json:"chain_version,omitempty"` //当前链版本
	}

	return ng.sdk.Helper().StateHelper().Get(keyOfWorldAppState(), new(appState)).(*appState).ChainVersion
}
