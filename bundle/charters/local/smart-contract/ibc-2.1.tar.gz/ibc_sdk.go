package IBC

//
////SetSdk This is a method of Dice2Win
//func (i *Ibc) SetSdk(sdk sdk.ISmartContract) {
//	i.sdk = sdk
//}
//
////GetSdk This is a method of Dice2Win
//func (i *Ibc) GetSdk() sdk.ISmartContract {
//	return i.sdk
//}
