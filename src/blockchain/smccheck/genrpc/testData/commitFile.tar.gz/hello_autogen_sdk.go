package hello

import (
	"blockchain/smcsdk/sdk"
)

//SetSdk This is a method of Hello
func (h *Hello) SetSdk(sdk sdk.ISmartContract) {
	h.sdk = sdk
}

//GetSdk This is a method of Hello
func (h *Hello) GetSdk() sdk.ISmartContract {
	return h.sdk
}