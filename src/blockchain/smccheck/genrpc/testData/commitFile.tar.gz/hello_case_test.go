package hello

import (
	"gopkg.in/check.v1"
	"blockchain/smcsdk/utest"
	"testing"
)

//Test This is a function
func Test(t *testing.T) { check.TestingT(t) }

//MySuite This is a struct
type MySuite struct{}

var _= check.Suite(&MySuite{})

//TestHello_SampleMethod This is a method of MySuite
func (mysuit *MySuite) TestHello_SampleMethod(c *check.C) () {
	utest.Init(orgID)
	contractOwner := utest.DeployContract(c, contractName, orgID, contractMethods)
	test := NewTestObject(contractOwner)

	//TODO
}
                            