package hello

import (
	"fmt"
)

//_setSampleStore This is a method of Hello
func (h *Hello) _setSampleStore(v string) {
	h.sdk.Helper().StateHelper().Set("/sampleStore", &v)
}

//_sampleStore This is a method of Hello
func (h *Hello) _sampleStore() string {

	return *h.sdk.Helper().StateHelper().GetEx("/sampleStore", new(string)).(*string)
}

//_chkSampleStore This is a method of Hello
func (h *Hello) _chkSampleStore() bool {
	return h.sdk.Helper().StateHelper().Check("/sampleStore")
}

//_setAaaa This is a method of Hello
func (h *Hello) _setAaaa(k1, k2 string, v *int) {
	h.sdk.Helper().StateHelper().McSet(fmt.Sprintf("/aaaa/%v/%v", k1, k2), v)
}

//_aaaa This is a method of Hello
func (h *Hello) _aaaa(k1, k2 string) *int {

	return h.sdk.Helper().StateHelper().McGetEx(fmt.Sprintf("/aaaa/%v/%v", k1, k2), new(int)).(*int)
}

//_clrAaaa This is a method of Hello
func (h *Hello) _clrAaaa(k1, k2 string) {
	h.sdk.Helper().StateHelper().McClear(fmt.Sprintf("/aaaa/%v/%v", k1, k2))
}

//_chkAaaa This is a method of Hello
func (h *Hello) _chkAaaa(k1, k2 string) bool {
	return h.sdk.Helper().StateHelper().Check(fmt.Sprintf("/aaaa/%v/%v", k1, k2))
}

//_McChkAaaa This is a method of Hello
func (h *Hello) _McChkAaaa(k1, k2 string) bool {
	return h.sdk.Helper().StateHelper().McCheck(fmt.Sprintf("/aaaa/%v/%v", k1, k2))
}

