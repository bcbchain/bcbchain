package hello

import (
	"blockchain/smcsdk/sdk"
)

//Hello This is struct of contract
//@:contract:hello
//@:version:1.0
//@:organization:orgNUjCm1i8RcoW2kVTbDw4vKW6jzfMxewJHjkhuiduhjuikjuyhnnjkuhujk111
//@:author:210f851d8da35ea17f5a2935e59579dce575b9bca0fe03d598967b74eb547e75
type Hello struct {
	sdk sdk.ISmartContract

	//This is a sample field which is to store in db
	//@:public:store
	sampleStore string

	//@:public:store:cache
	aaaa map[string]map[string]*int
}

//InitChain Constructor of this Hello
//@:constructor
func (h *Hello) InitChain() {

}

//SampleMethod This is a sample method
//@:public:method:gas[500]
func (h *Hello) SampleMethod() {

}
                         